﻿/**
 * JavaScript pour le formulaire de publication - Admin GRN-UCBC
 * Restauré le 12/11/2025
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log(' Formulaire de publication initialisé');
    
    // ================================================================
    // GESTION DES CHECKBOXES PERSONNALISÉES
    // ================================================================
    
    window.toggleCheckbox = function(id) {
        const checkbox = document.getElementById(id);
        const visual = document.getElementById('visual_' + id);
        const icon = document.getElementById('icon_' + id);
        const label = document.getElementById('label_' + id);
        
        if (!checkbox || !visual || !icon) return;
        
        checkbox.checked = !checkbox.checked;
        
        if (checkbox.checked) {
            visual.classList.add('bg-blue-600', 'border-blue-600');
            visual.classList.remove('border-gray-300');
            icon.classList.remove('hidden');
            label?.classList.add('bg-blue-50');
        } else {
            visual.classList.remove('bg-blue-600', 'border-blue-600');
            visual.classList.add('border-gray-300');
            icon.classList.add('hidden');
            label?.classList.remove('bg-blue-50');
        }
    };
    
    // ================================================================
    // COMPTEUR DE CARACTÈRES
    // ================================================================
    
    const resumeTextarea = document.getElementById('resume');
    const resumeCounter = document.getElementById('resume-count');
    
    if (resumeTextarea && resumeCounter) {
        const updateCounter = () => {
            const count = resumeTextarea.value.length;
            resumeCounter.textContent = count;
            
            if (count < 50) {
                resumeCounter.className = 'text-red-400';
            } else if (count > 500) {
                resumeCounter.className = 'text-yellow-400';
            } else {
                resumeCounter.className = 'text-gray-400';
            }
        };
        
        resumeTextarea.addEventListener('input', updateCounter);
        updateCounter();
    }
    
    // ================================================================
    // GESTION DES MODALS
    // ================================================================
    
    window.openAuthorModal = function() {
        const modal = document.getElementById('authorModal');
        if (modal) {
            modal.classList.remove('hidden');
            setTimeout(() => modal.classList.remove('opacity-0'), 10);
        }
    };
    
    window.closeAuthorModal = function() {
        const modal = document.getElementById('authorModal');
        if (modal) {
            modal.classList.add('opacity-0');
            setTimeout(() => modal.classList.add('hidden'), 300);
        }
    };
    
    window.openCategoryModal = function() {
        const modal = document.getElementById('categoryModal');
        if (modal) {
            modal.classList.remove('hidden');
            setTimeout(() => modal.classList.remove('opacity-0'), 10);
        }
    };
    
    window.closeCategoryModal = function() {
        const modal = document.getElementById('categoryModal');
        if (modal) {
            modal.classList.add('opacity-0');
            setTimeout(() => modal.classList.add('hidden'), 300);
        }
    };
    
    // ================================================================
    // UPLOAD DE FICHIERS PDF
    // ================================================================
    
    const fileInput = document.getElementById('fichier_pdf');
    
    if (fileInput) {
        console.log(' Champ fichier PDF trouvé');
        
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            
            if (file) {
                console.log(' Fichier sélectionné:', file.name);
                
                // Validation PDF
                if (file.type !== 'application/pdf') {
                    showNotification('Seuls les fichiers PDF sont autorisés', 'error');
                    this.value = '';
                    return;
                }
                
                // Validation taille
                if (file.size > 50 * 1024 * 1024) {
                    showNotification('Fichier trop volumineux (max 50MB)', 'error');
                    this.value = '';
                    return;
                }
                
                updateFileDisplay(file);
                showNotification('Fichier sélectionné avec succès', 'success');
            }
        });
        
        // Drag & Drop
        const dropZone = fileInput.parentElement;
        if (dropZone) {
            dropZone.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('border-blue-500', 'bg-blue-50');
            });
            
            dropZone.addEventListener('dragleave', function(e) {
                this.classList.remove('border-blue-500', 'bg-blue-50');
            });
            
            dropZone.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('border-blue-500', 'bg-blue-50');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    const file = files[0];
                    
                    if (file.type === 'application/pdf' && file.size <= 50 * 1024 * 1024) {
                        const dt = new DataTransfer();
                        dt.items.add(file);
                        fileInput.files = dt.files;
                        updateFileDisplay(file);
                        showNotification('Fichier ajouté par glisser-déposer', 'success');
                    } else {
                        showNotification('Fichier invalide', 'error');
                    }
                }
            });
        }
    }
    
    // ================================================================
    // FONCTIONS UTILITAIRES
    // ================================================================
    
    function updateFileDisplay(file) {
        const dropZone = fileInput?.parentElement;
        const textContainer = dropZone?.querySelector('.text-center');
        
        if (textContainer) {
            dropZone.classList.add('border-green-300', 'bg-green-50');
            textContainer.innerHTML = `
                <div class="text-center">
                    <div class="text-green-500 mb-2"> Fichier sélectionné</div>
                    <div class="font-medium">${file.name}</div>
                    <div class="text-sm text-gray-500">${formatFileSize(file.size)}</div>
                </div>
            `;
        }
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300`;
        
        const colors = {
            success: 'bg-green-500 text-white',
            error: 'bg-red-500 text-white',
            info: 'bg-blue-500 text-white'
        };
        
        notification.classList.add(...colors[type].split(' '));
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => notification.remove(), 3000);
    }
    
    // Rendre les fonctions globales
    window.showNotification = showNotification;
    window.formatFileSize = formatFileSize;
    
    console.log(' JavaScript entièrement restauré');
});
